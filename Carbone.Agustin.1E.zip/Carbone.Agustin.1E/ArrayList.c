#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"

// funciones privadas

/** \brief Increment the number of elements in this in AL_INCREMENT elements.
 * \param this ArrayList* Pointer to arrayList
 * \return int Return (-1) if Error [this is NULL pointer or if can't allocate memory]
 *                  - (0) if ok
 */
int resizeUp(ArrayList* this);

/** \brief Decrement the number of elements in this in 5 elements.
 * \param this ArrayList* Pointer to arrayList
 * \return int Return (-1) if Error [this is NULL pointer or if can't allocate memory]
 *                  - (0) if ok
 */
int resizeDown(ArrayList* this);

/** \brief  Expand an array list
 * \param this ArrayList* Pointer to arrayList
 * \param index int Index of the element
 * \return int Return (-1) if Error [this is NULL pointer or invalid index]
 *                  - ( 0) if Ok
 */
int expand(ArrayList* this,int index);

/** \brief  Contract an array list
 * \param this ArrayList* Pointer to arrayList
 * \param index int Index of the element
 * \return int Return (-1) if Error [this is NULL pointer or invalid index]
 *                  - ( 0) if Ok
 */
int contract(ArrayList* this,int index);

#define AL_INCREMENT      10
#define AL_INITIAL_VALUE  10
//___________________

ArrayList* al_newArrayList(void)
{
    ArrayList* this;
    ArrayList* returnAux = NULL;
    void* pElements;
    this = (ArrayList *)malloc(sizeof(ArrayList));

    if(this != NULL)
    {
        pElements = malloc(sizeof(void *)*AL_INITIAL_VALUE );
        if(pElements != NULL)
        {
            this->size=0;
            this->pElements=pElements;
            this->reservedSize=AL_INITIAL_VALUE;
            this->add=al_add;
            this->len=al_len;
            this->set=al_set;
            this->remove=al_remove;
            this->clear=al_clear;
            this->clone=al_clone;
            this->get=al_get;
            this->contains=al_contains;
            this->push=al_push;
            this->indexOf=al_indexOf;
            this->isEmpty=al_isEmpty;
            this->pop=al_pop;
            this->subList=al_subList;
            this->containsAll=al_containsAll;
            this->deleteArrayList = al_deleteArrayList;
            this->sort = al_sort;
            returnAux = this;
        }
        else
        {
            free(this);
        }
    }

    return returnAux;
}

int al_add(ArrayList* this, void* pElement)
{
    int returnAux = -1;

    if(this!=NULL && pElement!=NULL)
    {
        if(this->size < this->reservedSize)
        {
            this->pElements[this->size]=pElement;
            this->size++;
            returnAux=0;
        }
        else
        {
            if(!resizeUp(this))
               {
                   returnAux=1;
               }
        }
    }
    return returnAux;
}

int al_deleteArrayList(ArrayList* this)
{
    int returnAux = -1;

    if(this != NULL)
    {
        free(this);
        returnAux = 0;
    }
    return returnAux;
}

int al_len(ArrayList* this)
{
    int returnAux = -1;

    if(this != NULL)
    {
        returnAux = this->size;
    }
    return returnAux;
}

void* al_get(ArrayList* this, int index)
{
    void* returnAux = NULL;

    if(this != NULL && index >= 0 && index < this->size)
    {
        returnAux = this->pElements[index];
    }

    return returnAux;
}

int al_contains(ArrayList* this, void* pElement)
{
    int returnAux = -1;
    int i;

    if(this != NULL && pElement != NULL)
    {
        for(i=0 ;i < this->size; i++)
        {
            if(pElement == this->pElements[i])
            {
                returnAux = 1;
                break;
            }else
            {
                returnAux = 0;
            }
        }
    }
    return returnAux;
}

int al_set(ArrayList* this, int index,void* pElement)
{
    int returnAux = -1;

    if(this != NULL && pElement != NULL && index >= 0 && index < this->size)
    {
        this->pElements[index] = pElement;
        returnAux = 0;
    }
    return returnAux;
}

int al_remove(ArrayList* this,int index)
{
    int returnAux = -1;

    if(this != NULL && index >= 0 && index < this->size)
    {
        if(!contract(this,index))
            {
                returnAux = 0;
            }
    }
    return returnAux;
}

int al_clear(ArrayList* this)
{
    int returnAux = -1;

    if(this != NULL)
    {
        this->size = 0;
        returnAux = 0;
    }
    return returnAux;
}

ArrayList* al_clone(ArrayList* this)
{
    ArrayList* returnAux = NULL;

    if(this != NULL)
    {
        returnAux = this;
    }
    return returnAux;
}

int al_push(ArrayList* this, int index, void* pElement)
{
    int returnAux = -1;

    if(this != NULL && pElement != NULL && index >= 0 && index <= this->size)
    {
        if(!expand(this,index))
        {
            this->pElements[index] = pElement;
            returnAux = 0;
        }
    }
    return returnAux;
}

int al_indexOf(ArrayList* this, void* pElement)
{
    int returnAux = -1;
    int i;

    if(this != NULL && pElement != NULL)
    {
        for(i=0; i<this->size; i++)
        {
            if(pElement == this->pElements[i])
            {
                returnAux = i;
                break;
            }
        }
    }
    return returnAux;
}

int al_isEmpty(ArrayList* this)
{
    int returnAux = -1;

    if(this != NULL)
    {
        if(this->size > 0)
        {
            returnAux = 0;
        }else
        {
            returnAux = 1;
        }
    }
    return returnAux;
}

void* al_pop(ArrayList* this,int index)
{
    void* returnAux = NULL;

    if( this != NULL && index >=0 && index < this->size)
    {
        returnAux = this->pElements[index];
        al_remove(this,index);
    }
    return returnAux;
}

ArrayList* al_subList(ArrayList* this,int from,int to)
{
    ArrayList* returnAux = NULL;
    int i;

    if( this!=NULL && from >= 0 && from < this->size && to > 0 && to <= this->size && from < to)
    {
        returnAux= al_newArrayList();
        if(returnAux != NULL)
        {
            for(i=from; i<to ;i++)
            {
               if(al_add(returnAux,al_get(this,i)))
                {
                    al_deleteArrayList(returnAux);
                    returnAux=NULL;
                    break;
                }
            }
        }
    }
    return returnAux ;
}

int al_containsAll(ArrayList* this,ArrayList* this2)
{
    int returnAux = -1;
    int i;

    if(this != NULL && this2 != NULL)
    {
        for(i=0; i<this2->size; i++)
        {
            if(al_contains(this,this2->pElements[i]))
            {
                returnAux = 1;
            }else
            {
                returnAux = 0;
                break;
            }
        }
    }
    return returnAux;
}

int al_sort(ArrayList* this, int (*pFunc)(void* ,void*), int order)
{
    int returnAux = -1;
    int i;
    int swap;
    void* aux;

    if(this != NULL && pFunc != NULL && (order || !order))
    {
        do
        {
            swap = 1;

            for(i=0; i<(this->size-1); i++)
            {
                if(pFunc(al_get(this,i),al_get(this,i+1)) == -1 && !order)
                {
                    aux = al_get(this,i);
                    al_set(this,i,al_get(this,i+1));
                    al_set(this,i+1,aux);
                    returnAux = 1;
                    swap = 0;
                }
                if(pFunc(al_get(this,i),al_get(this,i+1)) && order);
                {
                    aux = al_get(this,i);
                    al_set(this,i,al_get(this,i+1));
                    al_set(this,i+1,aux);
                    returnAux = 0;
                    swap = 0;
                }
            }
        }while(swap == 0);
    }
    return returnAux;
}

int resizeUp(ArrayList* this)
{
    int returnAux = -1;
    void **auxPElement;
    if(this !=NULL)
    {
        if((this->size) == (this->reservedSize))
        {
            auxPElement= realloc(this->pElements,sizeof(void*)*(this->reservedSize+AL_INCREMENT));
            if(auxPElement!=NULL)
            {
                this->pElements=auxPElement;
                this->reservedSize+=AL_INCREMENT;
                returnAux=0;
            }
        }
        else
            returnAux=0;
    }

    return returnAux;

}

int expand(ArrayList* this,int index)
{
    int returnAux = -1;
    int i;

    if(this != NULL && index >=0 && index <= this->size)
    {
        this->size++;

        for(i=index; i<this->size; i++)
        {
            this->pElements[i+1] = this->pElements[i];
        }
        returnAux = 0;
    }
    return returnAux;
}

int contract(ArrayList* this,int index)
{
    int returnAux = -1;
    int i;

    if(this != NULL && index >= 0 && index < this->size)
    {
        for(i=index; i<this->size; i++)
        {
            this->pElements[i] = this->pElements[i+1];
            returnAux = 0;
        }
        this->size--;
    }

    return returnAux;
}

/** \brief
 *
 * \param this ArrayList* Pointer to arrayList
 * \param pFunc* int Pointer to function
 * \return int rweturn 0 if function return OK
                        -1 if a pointer is NULL or function not return 0
 *
 */
int al_map(ArrayList* this,int(*pFunc)(void*))
 {
    int retorno=-1;
    int i;
    if(this!=NULL&& pFunc!=NULL)
    {
        for(i=0;i<al_len(this);i++)
        {
            if(pFunc(this->pElements[i])==0)
            {
                retorno=0;
            }
        }

    }
    return retorno;
 }

int resizeDown(ArrayList* this)
{
    int returnAux = -1;
    void **auxPElement;
    if(this !=NULL)
    {
        while( ((this->size)+5) < (this->reservedSize))//mientras que size-5 sea menor a reserverSize itera.
        {
            auxPElement= realloc(this->pElements,sizeof(void*)*(this->reservedSize-5));
            if(auxPElement!=NULL)
            {
                this->pElements=auxPElement;
                this->reservedSize+= -5;
                returnAux=0;
            }
        }

    }

    return returnAux;

}

int al_filter(ArrayList* this, ArrayList* this2, int (*pFunc)(void*,int),int nivel)
{
    int i;
    int retorno = -1;

    if(this !=NULL && pFunc != NULL)
    {
        for(i=0;i<al_len(this);i++)
        {
            if(pFunc(this->pElements[i],nivel) == 0)
            {
                al_add(this2,this->pElements[i]);
                retorno = 0;
            }
        }
    }
    return retorno;
}

