#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Vendedor.h"

int parser_parseDatos(char* path, ArrayList* this)
{
    int retorno = -1;
    char bId[4096];
    char bNombre[4096];
    char bNivel[4096];
    char bCantProductosVendidos[4096];
    char bMontoVendido[4096];

    FILE* pFile;
    Vendedor* auxVendedor;

    if(path != NULL)
    {
        pFile = fopen(path,"r");
        retorno = 0;
        fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",bId,bNombre,bNivel,bCantProductosVendidos,bMontoVendido);
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",bId,bNombre,bNivel,bCantProductosVendidos,bMontoVendido);
            auxVendedor = vendedor_newParametros(bId,bNombre,bNivel,bCantProductosVendidos,bMontoVendido);
            al_add(this,auxVendedor);
        }
        printf(" archivo cargado\n");
    }
    return retorno;
}
