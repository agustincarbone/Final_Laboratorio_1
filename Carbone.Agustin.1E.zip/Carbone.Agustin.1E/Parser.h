#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

#include "ArrayList.h"

/** \brief lee archivos de un documento de texto
 *
 * \param path char* recibe el nombre del archivo
 * \param listaDeposito ArrayList* recibe la lista
 * \return int
 *
 */
int parser_parseDatos(char* path, ArrayList* this);

#endif // PARSER_H_INCLUDED
