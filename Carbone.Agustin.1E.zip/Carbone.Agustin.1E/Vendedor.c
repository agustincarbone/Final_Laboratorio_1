#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Vendedor.h"
#include "ArrayList.h"
#include "utn.h"

Vendedor* vendedor_new()
{
    Vendedor* this;
    this=malloc(sizeof(Vendedor));
    return this;
}

Vendedor* vendedor_newParametros(char* strId, char* nombre, char* strNivel, char* strCantProductosVendidos, char* strMontoVendido)
{
    int id;
    int nivel;
    int cantProductosVendidos;
    float montoVendido;

    Vendedor* this;

    id = atoi(strId);
    nivel = atoi(strNivel);
    cantProductosVendidos = atoi(strCantProductosVendidos);
    montoVendido = atof(strMontoVendido);

    this = vendedor_new();
    if( !vendedor_setId(this,id) &&
        !vendedor_setNombre(this,nombre) &&
        !vendedor_setNivel(this,nivel) &&
        !vendedor_setCantProductosVendidos(this,cantProductosVendidos) &&
        !vendedor_setMontoVendido(this,montoVendido) &&
        !vendedor_setComision(this,0)
        )
    {
        return this;
    }
    vendedor_delete(this);
    return NULL;
}

void vendedor_delete(Vendedor* this)
{
    free(this);
}

int vendedor_setId(Vendedor* this,int id)
{
    int retorno=-1;
    if(this!=NULL)
    {
        this->id=id;
        retorno=0;
    }
    return retorno;
}

int vendedor_getId(Vendedor* this,int* id)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *id=this->id;
        retorno=0;
    }
    return retorno;
}

int vendedor_setNombre(Vendedor* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        if(utn_esNombres(nombre))
        {
            strcpy(this->nombre,nombre);
            retorno=0;
        }
    }
    return retorno;
}

int vendedor_getNombre(Vendedor* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(nombre,this->nombre);
        retorno=0;
    }
    return retorno;
}

int vendedor_setMontoVendido(Vendedor* this,float montoVendido)
{
    int retorno=-1;
    if(this!=NULL)
    {
        this->montoVendido=montoVendido;
        retorno=0;
    }
    return retorno;
}

int vendedor_getMontoVendido(Vendedor* this,float* montoVendido)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *montoVendido=this->montoVendido;
        retorno=0;
    }
    return retorno;
}

int vendedor_setComision(Vendedor* this,float comision)
{
    int retorno=-1;
    if(this!=NULL)
    {
        this->comision=comision;
        retorno=0;
    }
    return retorno;
}

int vendedor_getComision(Vendedor* this,float* comision)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *comision=this->comision;
        retorno=0;
    }
    return retorno;
}

int vendedor_setNivel(Vendedor* this,int nivel)
{
    int retorno=-1;
    if(this!=NULL)
    {
        if(esNivel(nivel) == 0)
        {
            this->nivel=nivel;
            retorno=0;
        }
    }
    return retorno;
}

int vendedor_getNivel(Vendedor* this,int* nivel)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *nivel=this->nivel;
        retorno=0;
    }
    return retorno;
}

int esNivel(char nivel)
{
    int retorno = -1;

    if(nivel == 0 || nivel == 1 || nivel == 2)
    {
        retorno = 0;
    }

    return retorno;
}

int vendedor_setCantProductosVendidos(Vendedor* this,int cantProductosVendidos)
{
    int retorno=-1;

    if(this!=NULL)
    {
        this->cantProductosVendidos=cantProductosVendidos;
        retorno=0;
    }
    return retorno;
}

int vendedor_getCantProductosVendidos(Vendedor* this,int* cantProductosVendidos)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *cantProductosVendidos=this->cantProductosVendidos;
        retorno=0;
    }
    return retorno;
}

int vendedor_imprimirVendedor(ArrayList* this)
{
    int i;
    int retorno=-1;
    int auxId;
    char auxNombre[256];
    int auxNivel;
    int auxCantProductosVendidos;
    float auxMontoVendido;


    if(this!=NULL)
    {
        retorno=al_len(this);

        for(i=0; i<al_len(this); i++)
        {
            vendedor_getId(al_get(this,i),&auxId);
            vendedor_getNombre(al_get(this,i),auxNombre);
            vendedor_getNivel(al_get(this,i),&auxNivel);
            vendedor_getCantProductosVendidos(al_get(this,i),&auxCantProductosVendidos);
            vendedor_getMontoVendido(al_get(this,i),&auxMontoVendido);

            printf("ID: %d ",auxId);
            printf("Nombre: %s ",auxNombre);
            printf("Nivel: %d ",auxNivel);
            printf("Cantidad de productos vendidos: %d ",auxCantProductosVendidos);
            printf("Monto vendido: %f.2\n",auxMontoVendido);
        }
    }
    return retorno;
}

int generarArchivo(char* fileName,ArrayList* this)
{
    FILE* pFile;
    Vendedor* auxVendedor;
    int i;
    int auxId;
    char auxNombre[50];
    int auxNivel;
    int auxCantProductosVendidos;
    float auxMontoVendido;
    float auxComision;



    if(fileName!=NULL && this!=NULL)
    {
        pFile=fopen(fileName,"w");
        if(pFile!=NULL)
        {
            for(i=0; i<al_len(this); i++)
            {
                if(!i)
                {
                    fprintf(pFile,"ID,Nombre_vendedor,nivel,cantidad_productos_vendidos,Monto_vendido,Comision\n");
                }

                auxVendedor=al_get(this,i);
                vendedor_getId(auxVendedor,&auxId);
                vendedor_getNombre(auxVendedor,auxNombre);
                vendedor_getNivel(auxVendedor,&auxNivel);
                vendedor_getCantProductosVendidos(auxVendedor,&auxCantProductosVendidos);
                vendedor_getMontoVendido(auxVendedor,&auxMontoVendido);
                vendedor_getComision(auxVendedor,&auxComision);
                fprintf(pFile,"%d,%s,%d,%d,%f.2,%f.2\n",auxId,auxNombre,auxNivel,auxCantProductosVendidos,auxMontoVendido,auxComision);
            }
        }
        fclose(pFile);
    }
    return 0;
}

int vendedor_calcularComision(void* this)
{
    int retorno = -1;
    if(this != NULL)
    {
        Vendedor* aux= this;

        if(aux->nivel == 0)
        {
            aux->comision = (aux->montoVendido /100)*2;
        }
        else if(aux-> nivel == 1 || aux->nivel == 2)
        {
            if(aux->cantProductosVendidos < 100)
            {
                aux->comision = (aux->montoVendido /100)*3.5;
            }
            else if(aux->cantProductosVendidos >= 100)
            {
                aux->comision = (aux->montoVendido /100)*5;
            }
        }

        retorno = 0;
    }
    return retorno;
}

int vendedor_filtroNivel(void* this,int nivel)
{
    int retorno = -1;

    if(this != NULL)
    {
        Vendedor* aux= this;

        if(aux->nivel == (int)nivel)
        {
            retorno = 0;
        }
    }

    return retorno;
}
