#ifndef DATOS_H_INCLUDED
#define DATOS_H_INCLUDED

#include "ArrayList.h"

typedef struct
{
    int id;
    char nombre[256];
    int nivel;
    int cantProductosVendidos;
    float montoVendido;
    float comision;
}Vendedor;

Vendedor* vendedor_new();

Vendedor* vendedor_newParametros(char* strId, char* nombre, char* strNivel, char* strCantProductosVendidos, char* strMontoVendido);

void vendedor_delete(Vendedor* this);

int vendedor_setId(Vendedor* this,int id);
int vendedor_getId(Vendedor* this,int* id);

int vendedor_setNombre(Vendedor* this,char* nombre);
int vendedor_getNombre(Vendedor* this,char* nombre);

int vendedor_setNivel(Vendedor* this,int nivel);
int vendedor_getNivel(Vendedor* this,int* nivel);
int esNivel(char nivel);

int vendedor_setCantProductosVendidos(Vendedor* this,int cantProductosVendidos);
int vendedor_getCantProductosVendidos(Vendedor* this,int* cantProductosVendidos);

int vendedor_setMontoVendido(Vendedor* this,float montoVendido);
int vendedor_getMontoVendido(Vendedor* this,float* montoVendido);

int vendedor_setComision(Vendedor* this,float comision);
int vendedor_getComision(Vendedor* this,float* comision);

int vendedor_imprimirVendedor(ArrayList* this);

int generarArchivo(char* fileName,ArrayList* this);

int vendedor_calcularComision(void* this);
int vendedor_filtroNivel(void* this,int nivel);

#endif // DATOS_H_INCLUDED
