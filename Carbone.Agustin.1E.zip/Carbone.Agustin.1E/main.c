#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Parser.h"
#include "utn.h"
#include "Vendedor.h"

int main()
{
    int opcion, nivel;
    char* fileName = "DATA.csv";
    char respuesta = 's';
    ArrayList* listaDatos;
    ArrayList* auxArray;

    listaDatos = al_newArrayList();
    auxArray = al_newArrayList();

    do
    {
        opcion = 0;

        utn_getValidInt("\n elija una accion\n 1-cargar Archivo\n 2-imprimir Vendedores\n 3-Calcular comisiones\n 4-generar archivo de comiciones por nivel\n 5-salir\n"
                    ,"opcion invalida\n",&opcion,1,5,2);

        switch(opcion)
        {
            case 1:
                parser_parseDatos(fileName,listaDatos);
                break;
            case 2:
                vendedor_imprimirVendedor(listaDatos);
                break;
            case 3:
                al_map(listaDatos,vendedor_calcularComision);
                break;
            case 4:
                utn_getValidInt("\n elija un nivel: 0, 1, 2","nivel invalido\n",&nivel,0,2,2);
                al_filter(listaDatos,auxArray,vendedor_filtroNivel,nivel);
                generarArchivo("DATA2.csv",auxArray);
                al_clear(auxArray);
                break;
            case 5:
                respuesta = 'n';
                break;
        }
    }while(respuesta == 's');

    return 0;
}
